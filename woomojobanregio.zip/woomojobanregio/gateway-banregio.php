<?php
/*
Plugin Name: Banregio Colecto para Woocommerce
Plugin URI: https://mojomexico.company/portal/producto-categoria/woocommerce-wordpress/ 
Description: Pasarela Banco Banregio Colecto, aceptar tarjetas de credito y débito en tu tienda WooCommerce, preguntas, dudas y otras marcas de banco <a href="https://mojomexico.com.mx" target="_blank">dar clic aqui</a> para conocer nuestro catalogo.
Version: 0.1 Banregio 3D Security, Puedes orderar tu version final en nuestra tienda web.
Author: SR-Mojomexico 
Author URI: http://mojomexico.com.mx
Developer: SergioRomo by Mojomexico
Developer URI: https://mojomexico.com.mx/
Text Domain: Mojomexico Banregio Colecto

*/

if ( ! defined( 'ABSPATH' ) )
	exit;

add_action('plugins_loaded', 'woocommerce_banregio_init', 0);

function woocommerce_banregio_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) { return; }
        
        require_once(WP_PLUGIN_DIR . "/" . plugin_basename( dirname(__FILE__)) . '/woo_banregio.php');
        
	}
